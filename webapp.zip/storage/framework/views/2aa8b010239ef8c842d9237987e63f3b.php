<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Welcome User <?php echo e($name); ?> </title>
</head>
<body>
    <h1> <?php echo e($id); ?> <br> age: <?php echo e($age); ?> </h1>
</body>
</html>
<?php /**PATH C:\Users\Mark\webapp\resources\views/user.blade.php ENDPATH**/ ?>