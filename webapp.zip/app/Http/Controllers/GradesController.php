<?php

namespace App\Http\Controllers;

use App\Models\Members;
use App\Models\Grades;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;

class GradesController extends Controller
{
    public function showGrades()
    {
        $membersModel = new Members();
        $members = $membersModel->getAllMembers();

        return view('grades-page', compact('members'));
    }
    public function showProfile(Request $request)
    {
        $memberID = $request->query('memberID');
        $year = $request->input('year');
        $sem = $request->input('sem');

        $membersModel = new Members();
        $gradesModel = new Grades();
        $members = $membersModel->getMember($memberID);
        $grades = $gradesModel->getMemberGrades($memberID);
        return view('grades', compact('memberID', 'year', 'sem', 'members', 'grades'));
    }
    public function selectYearSem(Request $request)
    {
        $memberID = $request->memberID;
        $year = $request->input('year');
        $sem = $request->input('sem');

        $gradesModel = new Grades();
        $membersModel = new Members();
        $members = $membersModel->getMember($memberID);

        if ($year == '' && $sem == '') {
            $grades = $gradesModel->getMemberGrades($memberID);
        } else if ($sem == '') {
            $grades = $gradesModel->getMemberGradesByYear($memberID, $year);
        } else if ($year == '') {
            $grades = $gradesModel->getMemberGradesBySem($memberID, $sem);
        } else {
            $grades = $gradesModel->getMemberGradesByYearSem($memberID, $year, $sem);
        }

        return view('grades', compact('memberID', 'year', 'sem', 'grades', 'members'));
    }
    public function addNewGrades(Request $request)
    {
        if (request()->has('submit')) {

            $gradesData = request()->validate([
                'yearlevel' => 'required',
                'semester' => 'required',
                'course' => 'required',
                'code' => 'required',
                'unit' => 'required',
                'grades' => 'required',
                'memberID' => 'required'
            ]);

            $gradesData['memberID'] = $request->query('memberID');
            Grades::create($gradesData);

            return Redirect::to('/grades?memberID=' . $gradesData['memberID']);
        }
        return view('grades-add');
    }

    public function editGrades(Request $request)
    {
        $memberID = $request->memberID;
        $gradeID = $request->gradeID;
        $membersModel = new Members();
        $gradesModel = new Grades();
        $members = $membersModel->getMember($memberID);
        $grades = $gradesModel->getGrades($memberID, $gradeID);
        return view('grades-edit', compact('members', 'grades'));
    }

    public function updateGrades(Request $request)
    {
        $memberID = $request->memberID;
        $gradeID = $request->gradeID;

        $yearlevel = $request->input('yearlevel');
        $semester = $request->input('semester');
        $course = $request->input('course');
        $code = $request->input('code');
        $unit  = $request->input('unit');
        $grades = $request->input('grades');

        $update = Grades::where('memberID', $memberID)
        ->where('gradeID', $gradeID)
        ->update([
                'yearlevel' => $yearlevel,
                'semester' => $semester,
                'course' => $course,
                'code' => $code,
                'unit' => $unit,
                'grades' => $grades,
            ]); 
            $membersModel = new Members();
            $members = $membersModel->getMember($memberID);
            $gradesModel = new Grades();
            $grades = $gradesModel->getGrades($memberID, $gradeID);

            return view('grades',  compact('members', 'g rades'));
    }


    public function deleteGrades()
    {
        return view('grades-delete');
    }
}
